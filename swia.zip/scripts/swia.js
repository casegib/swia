/* eslint-disable no-console */
// Entry point for SWIA system

import { SWIAActorSheet } from "./sheets/swia-actor-sheet.js";
import { SWIACharacterSheet } from "./sheets/swia-character-sheet.js";
import { SWIAObjectSheet } from "./sheets/swia-object-sheet.js";
import { SWIAItemSheet } from "./sheets/swia-item-sheet.js";
import { SWIAPlayerPortal } from "./player-portal.js";
import { SWIACompanionPortal } from "./companion-portal.js";
import { SWIAImperialPortal } from "./imperial-portal.js";
import { SWIAGMPortal } from "./gm-portal.js";
import { SWIACampaignTracker } from "./campaign-tracker.js";
import { HeroData, VillainData, AllyData, CharacterData, ObjectData } from "./data/actors.js";
import {
  WeaponData, WeaponmodData, ArmorData, GearData, ClasscardData,
  AgendacardData, ImperialclasscardData, HeroabilityData, FormcardData
} from "./data/items.js";
import {
  registerDiceTerms, registerDiceSoNice, registerChatRenderHooks, checkLegacyDiceModule
} from "./dice/dice-terms.js";
import { registerRollCardHooks } from "./dice/roll-dialog.js";
import { registerCombatHooks, SWIACombatWindow } from "./dice/combat-window.js";

// Foundry v13+ namespaced APIs (system.json minimum is v13)
// The appv1 sheet classes are referenced only to unregister the core-registered defaults.
const CoreActorSheet = foundry.appv1.sheets.ActorSheet;
const CoreItemSheet = foundry.appv1.sheets.ItemSheet;
const loadTemplatesFn = foundry.applications.handlebars.loadTemplates;
const ActorsCollection = foundry.documents.collections.Actors;
const ItemsCollection = foundry.documents.collections.Items;
const LEGACY_ABILITY_MIGRATION_KEY = "schemaMigration";
const LEGACY_ABILITY_MIGRATION_VERSION = "0.0.5-ability-to-classcard";
const ROUND_STATE_KEY = "roundState";
const DEFAULT_ROUND_STATE = {
  round: 1,
  phase: "activation", // "activation" | "status"
  activationQueue: []  // ordered array of actor IDs, cleared each round
};

const CAMPAIGN_RESOURCES_KEY = "campaignResources";
const DEFAULT_CAMPAIGN_RESOURCES = {
  credits: 0,
  imperialInfluence: 0,
  threatLevel: 0,
  threat: 0,
  imperialXp: 0,
  xp: 0,
  requisition: 0,
  missions: []
};

// Defined at module scope so both init and setup hooks can apply it,
// ensuring it survives any module init hooks that overwrite CONFIG.statusEffects.
const SWIA_STATUS_EFFECTS = [
  // Combat Conditions
  { id: "weakened", name: "SWIA.Conditions.Weakened", img: "systems/swia/icons/Weaken.png" },
  { id: "stunned",  name: "SWIA.Conditions.Stunned",  img: "systems/swia/icons/Stunned.png" },
  { id: "bleeding", name: "SWIA.Conditions.Bleeding", img: "systems/swia/icons/Bleeding.png" },
  { id: "focused",  name: "SWIA.Conditions.Focused",  img: "systems/swia/icons/Focused.png" },
  { id: "hidden",   name: "SWIA.Conditions.Hidden",   img: "systems/swia/icons/Hidden.png" },
  { id: "blind",    name: "SWIA.Conditions.Blind",    img: "systems/swia/icons/Blind.png" },
  { id: "scanned",  name: "SWIA.Conditions.Scanned",  img: "systems/swia/icons/Scanned.png" },
  { id: "recon",    name: "SWIA.Conditions.Recon",    img: "systems/swia/icons/Recon.png" },
  { id: "wanted",   name: "SWIA.Conditions.Wanted",   img: "systems/swia/icons/Wanted.png" },
  // Power Tokens
  { id: "power-block",  name: "SWIA.PowerTokens.BlockToken",  img: "systems/swia/icons/Power Block Token.png" },
  { id: "power-damage", name: "SWIA.PowerTokens.DamageToken", img: "systems/swia/icons/Power Damage Token.png" },
  { id: "power-evade",  name: "SWIA.PowerTokens.EvadeToken",  img: "systems/swia/icons/Power Evade Token.png" },
  { id: "power-surge",  name: "SWIA.PowerTokens.SurgeToken",  img: "systems/swia/icons/Power Surge Token.png" },
  { id: "power-any",    name: "SWIA.PowerTokens.AnyToken",    img: "systems/swia/icons/Power Any Token.png" }
];

async function migrateLegacyAbilityItems() {
  if (!game.user?.isGM) return;

  const completedVersion = game.settings.get("swia", LEGACY_ABILITY_MIGRATION_KEY);
  if (completedVersion === LEGACY_ABILITY_MIGRATION_VERSION) return;

  let migratedActors = 0;
  let migratedItems = 0;

  for (const actor of game.actors?.contents ?? []) {
    const legacyItems = actor.items.filter((item) => item.type === "ability");
    if (!legacyItems.length) continue;

    const createData = legacyItems.map((item) => {
      const data = item.toObject();
      delete data._id;
      data.type = "classcard";
      data.system = data.system || {};
      if (typeof data.system.cooldown !== "number") data.system.cooldown = 0;
      return data;
    });

    await actor.createEmbeddedDocuments("Item", createData);
    await actor.deleteEmbeddedDocuments("Item", legacyItems.map((item) => item.id));

    migratedActors += 1;
    migratedItems += legacyItems.length;
  }

  await game.settings.set("swia", LEGACY_ABILITY_MIGRATION_KEY, LEGACY_ABILITY_MIGRATION_VERSION);

  if (migratedItems > 0) {
    console.log(`SWIA | Migrated ${migratedItems} legacy ability items on ${migratedActors} actor(s).`);
    ui.notifications?.info(`SWIA migrated ${migratedItems} legacy class card item(s).`);
  }
}

// Initialize system on Foundry ready
Hooks.once("init", async function initSWIA() {
  console.log("SWIA | Initializing Star Wars Imperial Assault system");

  // Register IA dice terms + chat/DSN/roll-card hooks (Phase 5)
  registerDiceTerms();
  registerDiceSoNice();
  registerChatRenderHooks();
  registerRollCardHooks();
  checkLegacyDiceModule();
  registerCombatHooks();

  // Register system data models (schemas live here; document types are declared in system.json)
  Object.assign(CONFIG.Actor.dataModels, {
    hero: HeroData,
    villain: VillainData,
    ally: AllyData,
    character: CharacterData,
    object: ObjectData
  });
  Object.assign(CONFIG.Item.dataModels, {
    weapon: WeaponData,
    weaponmod: WeaponmodData,
    armor: ArmorData,
    gear: GearData,
    classcard: ClasscardData,
    agendacard: AgendacardData,
    imperialclasscard: ImperialclasscardData,
    heroability: HeroabilityData,
    formcard: FormcardData
  });

  // Register custom Handlebars helpers for template rendering
  Handlebars.registerHelper("capitalize", (value) => {
    if (typeof value !== "string") return "";
    return value.charAt(0).toUpperCase() + value.slice(1);
  });

  // Helper to create array of specific length for iteration (e.g., rendering dice blocks)
  Handlebars.registerHelper("range", (count) => {
    const num = parseInt(count) || 0;
    if (num <= 0) return [];
    return Array.from({ length: num }, (_, i) => i);
  });

  // Helper for equality comparison in templates
  Handlebars.registerHelper("eq", (a, b) => a === b);

  // Helper for logical OR in templates
  Handlebars.registerHelper("or", (a, b) => a || b);

  // Helper for greater-than comparison in templates
  Handlebars.registerHelper("gt", (a, b) => a > b);

  // Define system namespace for shared data and config
  game.swia = {
    sheets: {},
    config: {}
  };

  game.settings.register("swia", LEGACY_ABILITY_MIGRATION_KEY, {
    name: "SWIA Schema Migration Version",
    scope: "world",
    config: false,
    type: String,
    default: ""
  });

  game.settings.register("swia", ROUND_STATE_KEY, {
    name: "SWIA Round State",
    scope: "world",
    config: false,
    type: Object,
    default: DEFAULT_ROUND_STATE
  });

  game.settings.register("swia", CAMPAIGN_RESOURCES_KEY, {
    name: "SWIA Campaign Resources",
    scope: "world",
    config: false,
    type: Object,
    default: DEFAULT_CAMPAIGN_RESOURCES
  });

  // Configure SWIA-specific status effects (conditions and power tokens)
  CONFIG.statusEffects = SWIA_STATUS_EFFECTS;

  // Preload Handlebars templates for actor and item sheets
  await loadTemplatesFn([
    "systems/swia/templates/actors/actor-sheet.hbs",
    "systems/swia/templates/actors/character-sheet.hbs",
    "systems/swia/templates/actors/object-sheet.hbs",
    "systems/swia/templates/actors/gm-portal.hbs",
    "systems/swia/templates/actors/player-portal.hbs",
    "systems/swia/templates/actors/companion-portal.hbs",
    "systems/swia/templates/actors/imperial-portal.hbs",
    "systems/swia/templates/campaign/campaign-tracker.hbs",
    "systems/swia/templates/items/classcard-sheet.hbs",
    "systems/swia/templates/items/weapon-sheet.hbs",
    "systems/swia/templates/items/weaponmod-sheet.hbs",
    "systems/swia/templates/items/armor-sheet.hbs",
    "systems/swia/templates/items/gear-sheet.hbs",
    "systems/swia/templates/items/heroability-sheet.hbs",
    "systems/swia/templates/items/formcard-sheet.hbs",
    "systems/swia/templates/dice/roll-dialog.hbs",
    "systems/swia/templates/dice/roll-card.hbs",
    "systems/swia/templates/dice/combat-window.hbs"
  ]);

  // Register actor sheets for hero, villain, and ally types
  ActorsCollection.unregisterSheet("core", CoreActorSheet);
  ActorsCollection.registerSheet("swia", SWIAActorSheet, {
    types: ["hero", "villain", "ally"],
    makeDefault: true
  });
  
  // Register separate sheet for Character type
  ActorsCollection.registerSheet("swia", SWIACharacterSheet, {
    types: ["character"],
    makeDefault: true
  });

  // Register separate sheet for Object type
  ActorsCollection.registerSheet("swia", SWIAObjectSheet, {
    types: ["object"],
    makeDefault: true
  });

  // Register item sheets
  ItemsCollection.unregisterSheet("core", CoreItemSheet);
  ItemsCollection.registerSheet("swia", SWIAItemSheet, {
    types: ["classcard", "agendacard", "imperialclasscard", "weapon", "weaponmod", "armor", "gear", "heroability", "formcard"],
    makeDefault: true
  });
});

// Re-apply status effects in the setup hook, which fires after all module init hooks.
// This ensures no module can overwrite CONFIG.statusEffects after us.
Hooks.once("setup", () => {
  CONFIG.statusEffects = SWIA_STATUS_EFFECTS;
});

Hooks.once("ready", async () => {
  try {
    await migrateLegacyAbilityItems();
  } catch (error) {
    console.error("SWIA | Legacy item migration failed", error);
    ui.notifications?.error("SWIA failed to migrate legacy class card items. Check console for details.");
  }
});

/**
 * Apply Character preferred disposition to newly created tokens
 */
Hooks.on("preCreateToken", (token, data, options, userId) => {
  if (!token.actor) return;
  
  // Only apply disposition for Character actor type
  if (token.actor.type !== "character") return;
  
  // Apply preferred disposition to token data, respecting the shown/hidden toggle
  const preferredDisposition = token.actor.system.preferredDisposition || "neutral";
  const dispositionShown = token.actor.getFlag("swia", "dispositionShown") ?? false;
  const effectiveDisposition = dispositionShown ? preferredDisposition : "neutral";

  // Convert preferred disposition to Foundry token disposition value:
  // "friendly" = 1, "neutral" = 0, "hostile" = -1
  const dispositionMap = {
    friendly: 1,
    neutral: 0,
    hostile: -1
  };

  data.disposition = dispositionMap[effectiveDisposition] ?? 0;
});

Hooks.on("renderActorDirectory", (app, html) => {
  if (!game.user) return;

  const root = html instanceof jQuery ? html : $(html);
  if (root.find(".swia-gm-portal-btn, .swia-player-portal-btn, .swia-companion-portal-btn, .swia-imperial-portal-btn, .swia-campaign-tracker-btn, .swia-combat-window-btn").length) return;

  const buttons = [];
  const buildDirectoryButton = ({ buttonClass, label, iconClass, onClick }) => {
    const button = $("<button>")
      .attr({
        type: "button",
        class: buttonClass,
        "aria-label": label,
        title: label
      });
    $("<i>")
      .addClass(iconClass)
      .attr("aria-hidden", "true")
      .appendTo(button);
    button.on("click", onClick);
    return button;
  };

  if (game.user.isGM) {
    buttons.push(buildDirectoryButton({
      buttonClass: "swia-gm-portal-btn",
      label: game.i18n.localize("SWIA.Portal.GM.Button"),
      iconClass: "fa-solid fa-user-shield",
      onClick: () => new SWIAGMPortal().render(true)
    }));
  }

  buttons.push(buildDirectoryButton({
    buttonClass: "swia-player-portal-btn",
    label: game.i18n.localize("SWIA.Portal.Button"),
    iconClass: "fa-brands fa-rebel",
    onClick: () => new SWIAPlayerPortal().render(true)
  }));

  buttons.push(buildDirectoryButton({
    buttonClass: "swia-companion-portal-btn",
    label: game.i18n.localize("SWIA.Portal.Companion.Button"),
    iconClass: "fa-solid fa-robot-astromech",
    onClick: () => new SWIACompanionPortal().render(true)
  }));

  if (game.user.isGM) {
    buttons.push(buildDirectoryButton({
      buttonClass: "swia-imperial-portal-btn",
      label: game.i18n.localize("SWIA.Portal.Imperial.Button"),
      iconClass: "fa-brands fa-empire",
      onClick: () => new SWIAImperialPortal().render(true)
    }));
  }

  buttons.push(buildDirectoryButton({
    buttonClass: "swia-campaign-tracker-btn",
    label: game.i18n.localize("SWIA.CampaignTracker.Button"),
    iconClass: "fa-solid fa-coins",
    onClick: () => new SWIACampaignTracker().render(true)
  }));

  buttons.push(buildDirectoryButton({
    buttonClass: "swia-combat-window-btn",
    label: game.i18n.localize("SWIA.Combat.Button"),
    iconClass: "fa-solid fa-crosshairs",
    onClick: () => SWIACombatWindow.show()
  }));

  const headerActions = root.find(".header-actions").first();
  if (headerActions.length) {
    buttons.forEach((button) => headerActions.append(button));
    return;
  }

  const directoryFooter = root.find(".directory-footer").first();
  if (directoryFooter.length) {
    buttons.forEach((button) => directoryFooter.append(button));
    return;
  }

  buttons.slice().reverse().forEach((button) => root.prepend(button));
});
